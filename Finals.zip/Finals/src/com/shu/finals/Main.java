package com.shu.finals;

public class Main {
	
	
	    public static void main(String[] args) {
	    	
	        Rectangle firstRectangle = new Rectangle(3, 4);
	        
	        System.out.println("This is First Rectangle: ");
	        
	        System.out.println("Length: " +3);
	        
	        System.out.println("Breadth: " +4);
	        
	        firstRectangle.getArea();
	        
	        firstRectangle.getPerimeter();
	        
	        System.out.println("this is Secong Rectangle: ");
	        
	        System.out.println("Length: " +7);
	        
	        System.out.println("Breadth: " +5);
	        
	        Rectangle secondRectangle = new Rectangle(7, 5);
	        
	        secondRectangle.getArea();
	        
	        secondRectangle.getPerimeter();
	    }

	}
