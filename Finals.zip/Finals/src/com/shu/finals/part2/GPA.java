package com.shu.finals.part2;

import java.util.Scanner;

public class GPA {

	
		public static void main(String args[])
		{
			Scanner sc=new Scanner(System.in);
			System.out.print("Enter Name: ");
			String name=sc.nextLine();
			System.out.print("Enter Grade Point: ");
			double grade=sc.nextDouble();
			//display the values
			display(name,grade);
		}
		
		
		public static void display(String name,double grade)
		{
			System.out.println("Name: "+name);
			System.out.println("Grade Point: "+grade);
			System.out.println("Student receives a $"+(grade*10)+" credit.");
		}
	}


	