package com.shu.finals.part2;

import java.util.Scanner;

public class Children {
	
	
		public static void main(String[] args) {
			
			Scanner sc= new Scanner(System.in);  
	        
			System.out.print("please enter number of  chidren in the group? ");  
	        
			int numChidren= sc.nextInt();  
	        
			int fixedsanFees = 50;
	        
			int cost;
	        
			if(numChidren > 0 && numChidren < 30){
	        
	            cost = (numChidren * 75) + 50;
	        }
	        else{
	            cost = (numChidren * 60) + 50;
	        }
	        System.out.println("Cost is $"+ cost + " for "+ numChidren+".");
	        
	        double num_sterile= Math.round((double)(numChidren) / (double)(10));
	        double num_gallons= Math.round((double)(numChidren) / (double)(20));
	        double num_tubs= Math.round((double)(numChidren) / (double)(15));
	        System.out.print("Have ready: "+(int)num_sterile+ " sterile meals, ");
	        System.out.print((int)num_gallons+" gallons of sanitizer and ");
	        System.out.print((int)num_tubs+" tubs of hand-towels");
	        
		}
	}


