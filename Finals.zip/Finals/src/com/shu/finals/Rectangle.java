package com.shu.finals;

public class Rectangle {
	
	    public int length;
	    public int breadth;
	   public Rectangle(int len, int b) {
	     length = len;
	     breadth = b;
	    }
	    public void getArea() {
	      System.out.println("Area of the rectangle is: " +(length * breadth));
	    }
	    public void getPerimeter() {
	      System.out.println("Perimeter of the rectangle is: " + 2 * (length + breadth));
	    }
	}

